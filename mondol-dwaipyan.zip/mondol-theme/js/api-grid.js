/**
 * Mondol Theme API Grid Script
 * Handles fetching API data and dynamic filtering
 * Mobile responsive and touch optimized
 * FIXED: Added _embed parameter to fetch featured images
 */

(function($) {
    

})(jQuery);